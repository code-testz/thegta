chrome.browserAction.onClicked.addListener(function () {
    chrome.tabs.query({active: true}, function (tabs) {
        var ok = [];
        var elementId = chrome.runtime.id.substr(0, 10);
        var len = tabs.length;
        for (var i = 0; (i < len); i++) {
            // game Grand Action Simulator will be enabled when ready
            var code = '(function(){window.game_enabled=(!window.game_enabled); return window[\'Game_Page_is_Ready_' + elementId + '\']})()';
            chrome.tabs.executeScript(tabs[i].id, {code: code}, function (a) {
                ok.push(!chrome.runtime.lastError && a.length && a[0] === '1')
            });
        }

        // wait for code execution
        var checkInterval = setInterval(function () {
            if (ok.length !== len)
                return;
            clearInterval(checkInterval);
            for (var i = 0; (i < len); i++) {
                if (ok[i] === true)
                    return;
            }

            chrome.tabs.create({url: "https://www.google.com/"}, function (tab) {
                chrome.tabs.executeScript(tab.id, {code: code}, function () {
                });
            })
        }, 100);
    })
});